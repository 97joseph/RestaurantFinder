package com.example.myyelp;

import com.google.gson.annotations.SerializedName;

public class YelpCategory {
    @SerializedName("title")
    String title;
}
