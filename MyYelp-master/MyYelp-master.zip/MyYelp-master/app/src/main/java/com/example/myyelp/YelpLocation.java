package com.example.myyelp;

import com.google.gson.annotations.SerializedName;

public class YelpLocation {
    @SerializedName("address1")
    String address;
}
